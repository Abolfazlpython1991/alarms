import pytse_client as tse_client
stock_name = 'وبملت'


ticker = tse_client.Ticker(stock_name)
print(ticker.adj_close)